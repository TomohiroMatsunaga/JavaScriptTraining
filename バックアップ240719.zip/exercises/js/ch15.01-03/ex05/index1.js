/* eslint-disable no-undef */

$("div#1000").html(_.capitalize("hello"));
