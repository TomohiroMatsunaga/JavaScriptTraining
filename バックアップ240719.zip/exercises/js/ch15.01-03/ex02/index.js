console.log("index.jsが読み込まれました");
const text = "Test"
// 文字列を返す関数
export function getText() {
    return "Test";
}
