console.log("aaa"); 
console.log("bbb" + "Hello World!".slice(12, 0));