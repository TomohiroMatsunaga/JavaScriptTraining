const { Person, greet } = require('./myModule');
module.exports = { Person, greet };
