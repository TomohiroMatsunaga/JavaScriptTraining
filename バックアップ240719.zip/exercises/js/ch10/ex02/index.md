AMD (Asynchronous Module Definition) 
AMDは非同期にモジュールを読み込むことができ、特にブラウザ環境でのモジュールローダーとして使われている。