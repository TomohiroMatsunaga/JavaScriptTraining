console.log('First import Strt');
import  './myModule.js';
console.log('First import End');

console.log('Second import Start');
import './myModule.js';
console.log('Second import End');