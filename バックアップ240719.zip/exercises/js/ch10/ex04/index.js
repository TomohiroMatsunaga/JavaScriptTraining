import { Human, hello } from './myModule.js';

const bob = new Human('Bob', 25);
bob.introduce();

hello();