'use strict';
let x = 10; //変数を宣言
function demo() {
    let y = 20; // 関数内の変数も宣言
    console.log(y);
}
demo();
console.log(x);