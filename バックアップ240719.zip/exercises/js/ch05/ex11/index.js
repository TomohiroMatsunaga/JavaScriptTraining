function debug() {
    debugger; 
}
