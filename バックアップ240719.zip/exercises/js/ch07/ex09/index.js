const yoshi = "𠮷野家";
const family = "👨‍👨‍👧‍👧";
console.log(`${yoshi[0]}, ${family[0]}`);