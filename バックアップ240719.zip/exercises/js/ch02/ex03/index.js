// NFC形式
var nfc = "\u30D1\u30F3".normalize('NFC');

// NFD形式
var nfd = "\u30D1\u30F3".normalize('NFD');

console.log(`NFC = ${nfc}, NFD = ${nfd}`);