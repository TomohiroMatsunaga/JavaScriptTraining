console.log('Infinity + Infinity: ', Infinity + Infinity);
console.log('Infinity - Infinity: ', Infinity - Infinity);
console.log('Infinity * Infinity: ', Infinity * Infinity);
console.log('Infinity / Infinity: ', Infinity / Infinity);

console.log('Infinity + NaN: ', Infinity + NaN);
console.log('Infinity - NaN: ', Infinity - NaN);
console.log('Infinity * NaN: ', Infinity * NaN);
console.log('Infinity / NaN: ', Infinity / NaN);
console.log('Infinity - NaN: ', Infinity - NaN);
console.log('NaN - Infinity: ', NaN -Infinity);
console.log('NaN / Infinity: ', NaN / Infinity);

console.log('NaN + NaN: ', NaN + NaN);
console.log('NaN - NaN: ', NaN - NaN);
console.log('NaN * NaN: ', NaN * NaN);
console.log('NaN / NaN: ', NaN / NaN);