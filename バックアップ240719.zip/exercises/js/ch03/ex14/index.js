export function eq(a, b) {
  // TODO: ここを実装しなさい
  return false;
}

export function lte(a, b) {
  // TODO: ここを実装しなさい
  return false;
}
