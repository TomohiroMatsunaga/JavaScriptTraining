console.log('最大値: ', Number.MAX_SAFE_INTEGER);
console.log('最小値: ', Number.MIN_SAFE_INTEGER);

console.log('最大値 + 1: ', Number.MAX_SAFE_INTEGER + 1);

console.log('最大値 + 1 と 最大値 + 2 の比較: ', Number.MAX_SAFE_INTEGER + 1 === Number.MAX_SAFE_INTEGER + 2);
