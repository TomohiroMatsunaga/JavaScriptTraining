function myFunction() {
    return "Hello, World!";
}

// ユーザー定義関数の toString()
console.log(myFunction.toString());

// 組み込み関数の toString()
console.log(Math.abs.toString());